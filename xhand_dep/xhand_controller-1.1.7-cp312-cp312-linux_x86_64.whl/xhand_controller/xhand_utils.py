from . import xhand_control


def main():
    print(xhand_control.get_sdk_version())

if __name__ == "__main__":
    main()